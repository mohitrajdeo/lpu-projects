import React, { useState, useEffect } from 'react';

export default function App() {
  const [ip, setIp] = useState('203.0.113.88');
  const [pkt, setPkt] = useState(450);
  const [pps, setPps] = useState(600);
  const [syn, setSyn] = useState(75);
  const [port, setPort] = useState(80);

  const [attackType, setAttackType] = useState('DDoS');
  const [confidence, setConfidence] = useState(100.0);
  const [threatRiskScore, setThreatRiskScore] = useState(95);
  const [techniqueId, setTechniqueId] = useState('T1498.001');
  const [tactic, setTactic] = useState('Impact');
  const [quarantineStatus, setQuarantineStatus] = useState('BLOCKED & ISOLATED');
  const [ctiBrief, setCtiBrief] = useState('Waiting for threat triage trigger...');
  const [latencyMs, setLatencyMs] = useState(3.8);
  const [copied, setCopied] = useState(false);

  const executeTriage = async (pLen = pkt, pRate = pps, sCount = syn, tPort = port, sIp = ip) => {
    const t0 = performance.now();
    try {
      const res = await fetch('/api/secops/triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pkt_len: pLen,
          duration: 0.5,
          fwd_pkts: pRate,
          syn_flags: sCount,
          port: tPort,
          source_ip: sIp
        })
      });
      const data = await res.json();
      setLatencyMs(Math.round(performance.now() - t0));

      const isThreat = data.triage.is_threat;
      setAttackType(data.triage.attack_type);
      setConfidence(Number((data.triage.confidence_score * 100).toFixed(1)));
      setThreatRiskScore(Math.round(data.triage.threat_risk_score || (isThreat ? 95 : 5)));
      setTechniqueId(data.threat_intelligence.technique_id || '--');
      setTactic(data.threat_intelligence.tactic || '--');
      setQuarantineStatus(isThreat ? 'BLOCKED & ISOLATED' : 'ACTIVE MONITORING');
      setCtiBrief(data.cti_brief);
    } catch (err) {
      setCtiBrief('SecOps Microservice API Error: ' + err.message);
    }
  };

  useEffect(() => {
    executeTriage();
  }, []);

  const setPreset = (pLen, pRate, sCount, tPort) => {
    setPkt(pLen);
    setPps(pRate);
    setSyn(sCount);
    setPort(tPort);
    executeTriage(pLen, pRate, sCount, tPort, ip);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(ctiBrief);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isMalicious = attackType !== 'Normal Traffic';

  return (
    <div>
      {/* Header */}
      <header>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div className="brand-badge">🔒</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h1 style={{ fontSize: '16px', fontWeight: 800 }}>SOC Cyber Threat Hunter</h1>
              <span className="chip" style={{ color: 'var(--accent-rose)', borderColor: 'rgba(244,63,94,0.3)' }}>v2.0 React</span>
            </div>
            <p style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Student: Saif Siddique (12308813 | Roll: 44) | INT422 Capstone</p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div className="chip">PORT: 5003</div>
          <div className="chip">LATENCY: {latencyMs}ms</div>
          <div className="status-chip">
            <span className="pulse-dot"></span>
            <span>MICROSERVICE ONLINE</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main>
        {/* 4-Stage Agent State Pipeline */}
        <div className="pipeline-tracker">
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 1: Triage</div>
            <div className="pipeline-title">Flow Ingestion</div>
            <div className="pipeline-desc">Real-time packet feature extraction & buffer</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 2: Deep MLP Net</div>
            <div className="pipeline-title">Intrusion Classifier</div>
            <div className="pipeline-desc">Multi-class flow classification neural net</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 3: MITRE ATT&CK</div>
            <div className="pipeline-title">Threat Intel RAG</div>
            <div className="pipeline-desc">Adversary technique & IOC correlation</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 4: Active Defense</div>
            <div className="pipeline-title">Zero Trust Containment</div>
            <div className="pipeline-desc">Linux Netfilter, nftables & AWS security rules</div>
          </div>
        </div>

        {/* Metric Cards Row */}
        <div className="grid-4">
          <div className="stat-card">
            <div className="stat-label">Threat Classification</div>
            <div className="stat-val" style={{ color: isMalicious ? 'var(--accent-rose)' : 'var(--accent-emerald)' }}>
              {attackType}
            </div>
            <div className="stat-sub">Neural Confidence: <span style={{ color: '#fff' }}>{confidence}%</span></div>
          </div>

          <div className="stat-card">
            <div className="stat-label">Threat Risk Score</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', margin: '8px 0' }}>
              <div style={{ position: 'relative', width: '74px', height: '74px' }}>
                <svg style={{ transform: 'rotate(-90deg)', width: '74px', height: '74px' }}>
                  <circle cx="37" cy="37" r="30" fill="none" stroke="#1e293b" strokeWidth="7" />
                  <circle
                    cx="37"
                    cy="37"
                    r="30"
                    fill="none"
                    stroke={threatRiskScore > 50 ? 'var(--accent-rose)' : 'var(--accent-emerald)'}
                    strokeWidth="7"
                    strokeDasharray="188.5"
                    strokeDashoffset={188.5 - (188.5 * (threatRiskScore / 100))}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dashoffset 0.4s ease, stroke 0.3s ease' }}
                  />
                </svg>
                <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontFamily: 'JetBrains Mono', fontSize: '14px', fontWeight: 800 }}>
                  {threatRiskScore}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 800, color: threatRiskScore > 50 ? 'var(--accent-rose)' : 'var(--accent-emerald)' }}>
                  {threatRiskScore > 50 ? 'HIGH RISK' : 'LOW RISK'}
                </div>
                <div className="stat-sub">Blast Radius Index</div>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-label">MITRE Technique ID</div>
            <div className="stat-val" style={{ fontSize: '15px', marginTop: '8px', color: 'var(--accent-cyan)' }}>
              {techniqueId}
            </div>
            <div className="stat-sub">Tactic: <span style={{ color: '#fff' }}>{tactic}</span></div>
          </div>

          <div className="stat-card">
            <div className="stat-label">Perimeter Quarantine</div>
            <div className="stat-val" style={{ color: isMalicious ? 'var(--accent-rose)' : 'var(--accent-emerald)', fontSize: '16px', marginTop: '8px' }}>
              {quarantineStatus}
            </div>
            <div className="stat-sub">Zero-Trust Packet Filtering</div>
          </div>
        </div>

        {/* 2-Column Main Content */}
        <div className="grid-2">
          {/* Controls Column */}
          <div>
            <div className="card">
              <div className="card-header">
                <span className="card-title">Network Packet Flow Synthesizer</span>
                <span className="chip" style={{ fontSize: '10px' }}>Flow Vector</span>
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>Adversary Source IP</span>
                  <span>Attacker Origin</span>
                </div>
                <input
                  type="text"
                  value={ip}
                  onChange={(e) => setIp(e.target.value)}
                  style={{ width: '100%', background: '#030712', border: '1px solid var(--border)', borderRadius: '6px', padding: '8px 12px', color: '#fff', fontFamily: 'JetBrains Mono', fontSize: '12px' }}
                />
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>Packet Length (Bytes)</span>
                  <span>{pkt} B</span>
                </div>
                <input type="range" min="40" max="1500" value={pkt} onChange={(e) => { setPkt(Number(e.target.value)); executeTriage(Number(e.target.value), pps, syn, port, ip); }} />
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>Packets Per Second (PPS)</span>
                  <span>{pps} PPS</span>
                </div>
                <input type="range" min="5" max="1000" value={pps} onChange={(e) => { setPps(Number(e.target.value)); executeTriage(pkt, Number(e.target.value), syn, port, ip); }} />
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>TCP SYN Flags Count</span>
                  <span>{syn}</span>
                </div>
                <input type="range" min="0" max="100" value={syn} onChange={(e) => { setSyn(Number(e.target.value)); executeTriage(pkt, pps, Number(e.target.value), port, ip); }} />
              </div>

              <div className="card-header" style={{ marginTop: '16px' }}>
                <span className="card-title" style={{ fontSize: '13px' }}>🚨 Adversarial Attack Injection Presets</span>
              </div>
              <div className="btn-group">
                <button className="btn btn-outline" onClick={() => setPreset(400, 15, 1, 443)}>Enterprise Flow</button>
                <button className="btn btn-red" onClick={() => setPreset(450, 750, 85, 80)}>🚨 SYN Flood (DDoS)</button>
                <button className="btn btn-red" onClick={() => setPreset(60, 45, 2, 22)}>🚨 PortScan (T1046)</button>
                <button className="btn btn-red" onClick={() => setPreset(1450, 30, 1, 80)}>🚨 SQL Injection (T1190)</button>
              </div>
            </div>
          </div>

          {/* Terminal Output */}
          <div>
            <div className="card">
              <div className="card-header">
                <span className="card-title">Autonomous SOC Threat Intelligence Brief</span>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn btn-outline" onClick={handleCopy}>
                    {copied ? '✓ Copied!' : '📋 Copy CTI Brief'}
                  </button>
                  <button className="btn btn-red" onClick={() => executeTriage()}>
                    ⚡ Ingest & Mitigate
                  </button>
                </div>
              </div>
              <div className="terminal-box">{ctiBrief}</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
