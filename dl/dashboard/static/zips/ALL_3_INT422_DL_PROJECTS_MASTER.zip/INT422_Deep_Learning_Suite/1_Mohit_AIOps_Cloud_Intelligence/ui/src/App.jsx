import React, { useState, useEffect, useRef } from 'react';

export default function App() {
  const [cpu, setCpu] = useState(22);
  const [mem, setMem] = useState(41);
  const [lat, setLat] = useState(18);
  const [sock, setSock] = useState(120);

  const [healthIndex, setHealthIndex] = useState(98.2);
  const [isAnomaly, setIsAnomaly] = useState(false);
  const [anomalyScore, setAnomalyScore] = useState(0.152);
  const [matchedRunbook, setMatchedRunbook] = useState('None (System Healthy)');
  const [ragConfidence, setRagConfidence] = useState(95);
  const [mttr, setMttr] = useState(0);
  const [rcaReport, setRcaReport] = useState('Waiting for telemetry ingestion...');
  const [latencyMs, setLatencyMs] = useState(3.4);
  const [copied, setCopied] = useState(false);

  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  // Initialize and update Chart.js
  useEffect(() => {
    if (window.Chart && chartRef.current) {
      if (!chartInstance.current) {
        chartInstance.current = new window.Chart(chartRef.current, {
          type: 'line',
          data: {
            labels: ['-50s', '-40s', '-30s', '-20s', '-10s', 'Now'],
            datasets: [
              {
                label: 'CPU %',
                data: [20, 22, 21, 24, 22, cpu],
                borderColor: '#38bdf8',
                backgroundColor: 'rgba(56, 189, 248, 0.1)',
                borderWidth: 2,
                tension: 0.35,
                fill: true,
                pointRadius: 3
              },
              {
                label: 'RAM %',
                data: [40, 41, 41, 42, 40, mem],
                borderColor: '#818cf8',
                backgroundColor: 'rgba(129, 140, 248, 0.1)',
                borderWidth: 2,
                tension: 0.35,
                fill: true,
                pointRadius: 3
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: '#94a3b8', font: { size: 10 } } } },
            scales: {
              y: { min: 0, max: 100, ticks: { color: '#64748b', font: { size: 9 } }, grid: { color: 'rgba(255,255,255,0.05)' } },
              x: { ticks: { color: '#64748b', font: { size: 9 } }, grid: { display: false } }
            }
          }
        });
      } else {
        const d = chartInstance.current.data.datasets;
        d[0].data.shift();
        d[0].data.push(cpu);
        d[1].data.shift();
        d[1].data.push(mem);
        chartInstance.current.update();
      }
    }
  }, [cpu, mem]);

  const sendTelemetry = async (cVal = cpu, mVal = mem, lVal = lat, sVal = sock) => {
    const t0 = performance.now();
    try {
      const res = await fetch('/api/aiops/telemetry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cpu: cVal, memory: mVal, latency: lVal, sockets: sVal })
      });
      const data = await res.json();
      setLatencyMs(Math.round(performance.now() - t0));

      setHealthIndex(data.monitoring.system_health_index || 95.0);
      setIsAnomaly(data.monitoring.is_anomaly);
      setAnomalyScore(data.monitoring.anomaly_score);
      setMatchedRunbook(data.investigation.retrieved_runbook.title);
      setRagConfidence(Math.round((data.investigation.rag_confidence || 0.9) * 100));
      setMttr(data.remediation.estimated_recovery_time_sec || 12);
      setRcaReport(data.rca_report);
    } catch (err) {
      setRcaReport('AIOps Microservice API Error: ' + err.message);
    }
  };

  useEffect(() => {
    sendTelemetry(cpu, mem, lat, sock);
  }, []);

  const setPreset = (cVal, mVal, lVal, sVal) => {
    setCpu(cVal);
    setMem(mVal);
    setLat(lVal);
    setSock(sVal);
    sendTelemetry(cVal, mVal, lVal, sVal);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(rcaReport);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const circumference = 2 * Math.PI * 34; // ~213.6
  const strokeOffset = circumference - (circumference * (healthIndex / 100));

  return (
    <div>
      {/* Header */}
      <header>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div className="brand-badge">Δ</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h1 style={{ fontSize: '16px', fontWeight: 800 }}>AIOps Cloud Intelligence</h1>
              <span className="chip" style={{ color: 'var(--accent-blue)', borderColor: 'rgba(56,189,248,0.3)' }}>v2.0 React</span>
            </div>
            <p style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Student: Mohit Raj Deo (12323329 | Roll: 62) | INT422 Capstone</p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div className="chip">PORT: 5001</div>
          <div className="chip">LATENCY: {latencyMs}ms</div>
          <div className="status-chip">
            <span className="pulse-dot"></span>
            <span>MICROSERVICE ONLINE</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main>
        {/* 4-Stage Agent State Pipeline */}
        <div className="pipeline-tracker">
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 1: Ingestion</div>
            <div className="pipeline-title">Telemetry Streamer</div>
            <div className="pipeline-desc">Real-time rolling buffer & trend gradients</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 2: Inference</div>
            <div className="pipeline-title">Isolation Forest</div>
            <div className="pipeline-desc">Unsupervised anomaly scoring model</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 3: Vector RAG</div>
            <div className="pipeline-title">Runbook Matcher</div>
            <div className="pipeline-desc">Cosine similarity ranking over SRE DB</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 4: Autonomous</div>
            <div className="pipeline-title">Self-Healing Healer</div>
            <div className="pipeline-desc">Automated mitigation & MTTR audit</div>
          </div>
        </div>

        {/* Metric Cards Row */}
        <div className="grid-4">
          <div className="stat-card">
            <div className="stat-label">System Health Index</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', margin: '8px 0' }}>
              <div style={{ position: 'relative', width: '74px', height: '74px' }}>
                <svg style={{ transform: 'rotate(-90deg)', width: '74px', height: '74px' }}>
                  <circle cx="37" cy="37" r="30" fill="none" stroke="#1e293b" strokeWidth="7" />
                  <circle
                    cx="37"
                    cy="37"
                    r="30"
                    fill="none"
                    stroke={healthIndex < 50 ? 'var(--accent-rose)' : (healthIndex < 75 ? 'var(--accent-amber)' : 'var(--accent-emerald)')}
                    strokeWidth="7"
                    strokeDasharray="188.5"
                    strokeDashoffset={188.5 - (188.5 * (healthIndex / 100))}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dashoffset 0.4s ease, stroke 0.3s ease' }}
                  />
                </svg>
                <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontFamily: 'JetBrains Mono', fontSize: '14px', fontWeight: 800 }}>
                  {Math.round(healthIndex)}%
                </div>
              </div>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 800, color: healthIndex < 50 ? 'var(--accent-rose)' : (healthIndex < 75 ? 'var(--accent-amber)' : 'var(--accent-emerald)') }}>
                  {healthIndex < 50 ? 'CRITICAL' : (healthIndex < 75 ? 'DEGRADED' : 'OPTIMAL')}
                </div>
                <div className="stat-sub">SLA Target: &gt; 95%</div>
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-label">ML Anomaly Status</div>
            <div className="stat-val" style={{ color: isAnomaly ? 'var(--accent-rose)' : 'var(--accent-emerald)' }}>
              {isAnomaly ? 'ANOMALY DETECTED' : 'NORMAL'}
            </div>
            <div className="stat-sub">Decision Score: <span style={{ color: '#fff' }}>{anomalyScore}</span></div>
          </div>

          <div className="stat-card">
            <div className="stat-label">Matched SRE Runbook</div>
            <div className="stat-val" style={{ fontSize: '14px', marginTop: '8px', color: 'var(--accent-cyan)', lineHeight: 1.4 }}>
              {matchedRunbook}
            </div>
            <div className="stat-sub">Vector RAG Confidence: <span style={{ color: '#fff' }}>{ragConfidence}%</span></div>
          </div>

          <div className="stat-card">
            <div className="stat-label">Estimated MTTR</div>
            <div className="stat-val" style={{ color: 'var(--accent-amber)' }}>
              {mttr}s
            </div>
            <div className="stat-sub">Autonomous Self-Healing Loop</div>
          </div>
        </div>

        {/* 2-Column Main Content */}
        <div className="grid-2">
          {/* Controls Column */}
          <div>
            <div className="card">
              <div className="card-header">
                <span className="card-title">Live Telemetry Ingestion Controls</span>
                <span className="chip" style={{ fontSize: '10px' }}>4 Features</span>
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>CPU Utilization</span>
                  <span>{cpu}%</span>
                </div>
                <input type="range" min="5" max="100" value={cpu} onChange={(e) => { setCpu(Number(e.target.value)); sendTelemetry(Number(e.target.value), mem, lat, sock); }} />
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>Memory Consumption</span>
                  <span>{mem}%</span>
                </div>
                <input type="range" min="10" max="100" value={mem} onChange={(e) => { setMem(Number(e.target.value)); sendTelemetry(cpu, Number(e.target.value), lat, sock); }} />
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>HTTP / TCP Latency</span>
                  <span>{lat}ms</span>
                </div>
                <input type="range" min="5" max="500" value={lat} onChange={(e) => { setLat(Number(e.target.value)); sendTelemetry(cpu, mem, Number(e.target.value), sock); }} />
              </div>

              <div className="control-group">
                <div className="control-label">
                  <span>Active Sockets</span>
                  <span>{sock}</span>
                </div>
                <input type="range" min="20" max="1000" value={sock} onChange={(e) => { setSock(Number(e.target.value)); sendTelemetry(cpu, mem, lat, Number(e.target.value)); }} />
              </div>

              {/* Sparkline Canvas */}
              <div className="card-header" style={{ marginTop: '16px', marginBottom: '8px' }}>
                <span className="card-title" style={{ fontSize: '12px' }}>📊 Live Telemetry Stream Trend</span>
              </div>
              <div style={{ position: 'relative', height: '140px', width: '100%' }}>
                <canvas ref={chartRef}></canvas>
              </div>

              <div className="card-header" style={{ marginTop: '16px' }}>
                <span className="card-title" style={{ fontSize: '13px' }}>🚨 Chaos Fault Injection Presets</span>
              </div>
              <div className="btn-group">
                <button className="btn btn-outline" onClick={() => setPreset(22, 40, 18, 120)}>Normal Traffic</button>
                <button className="btn btn-red" onClick={() => setPreset(94, 92, 240, 430)}>Memory Leak (RB-104)</button>
                <button className="btn btn-red" onClick={() => setPreset(98, 55, 180, 210)}>CPU Saturation (RB-108)</button>
                <button className="btn btn-red" onClick={() => setPreset(65, 70, 420, 850)}>Network Thrashing (RB-212)</button>
              </div>
            </div>
          </div>

          {/* Terminal Output */}
          <div>
            <div className="card">
              <div className="card-header">
                <span className="card-title">AIOps Autonomous Multi-Agent Response Stream</span>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn btn-outline" onClick={handleCopy}>
                    {copied ? '✓ Copied!' : '📋 Copy RCA'}
                  </button>
                  <button className="btn" onClick={() => sendTelemetry()}>
                    ⚡ Ingest Telemetry
                  </button>
                </div>
              </div>
              <div className="terminal-box">{rcaReport}</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
