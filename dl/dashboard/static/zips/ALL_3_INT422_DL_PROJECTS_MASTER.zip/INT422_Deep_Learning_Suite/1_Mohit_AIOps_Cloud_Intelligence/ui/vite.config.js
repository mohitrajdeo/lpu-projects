import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3001,
    proxy: {
      '/api': 'http://localhost:5001',
      '/health': 'http://localhost:5001',
      '/metrics': 'http://localhost:5001'
    }
  }
})
