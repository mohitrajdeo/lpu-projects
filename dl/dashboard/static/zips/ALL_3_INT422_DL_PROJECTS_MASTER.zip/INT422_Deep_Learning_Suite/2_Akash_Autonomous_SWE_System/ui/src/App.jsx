import React, { useState, useEffect, useRef } from 'react';

export default function App() {
  const [prompt, setPrompt] = useState('Build a high-performance sliding window API Rate Limiter in Python with auto cleanup');
  const [maintainabilityIndex, setMaintainabilityIndex] = useState(55.5);
  const [cyclomaticComplexity, setCyclomaticComplexity] = useState(4);
  const [loc, setLoc] = useState(19);
  const [astDepth, setAstDepth] = useState(10);
  const [defectRisk, setDefectRisk] = useState('CLEAN (Production Ready)');
  const [defectProbability, setDefectProbability] = useState(1.2);
  const [testStatus, setTestStatus] = useState('PASS');
  const [coveragePct, setCoveragePct] = useState(100.0);
  const [codeOutput, setCodeOutput] = useState('Waiting for SWE swarm execution...');
  const [latencyMs, setLatencyMs] = useState(4.2);
  const [copied, setCopied] = useState(false);

  const radarRef = useRef(null);
  const radarInstance = useRef(null);

  // Initialize and update Radar Chart
  useEffect(() => {
    if (window.Chart && radarRef.current) {
      if (!radarInstance.current) {
        radarInstance.current = new window.Chart(radarRef.current, {
          type: 'radar',
          data: {
            labels: ['Maintainability', 'Test Coverage', 'AST Simplicity', 'Cleanliness', 'Security Compliance'],
            datasets: [{
              label: 'Code Quality Vector',
              data: [maintainabilityIndex, coveragePct, 80, 95, 90],
              borderColor: '#818cf8',
              backgroundColor: 'rgba(129, 140, 248, 0.2)',
              borderWidth: 2,
              pointBackgroundColor: '#38bdf8'
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
              r: {
                min: 0,
                max: 100,
                ticks: { display: false },
                grid: { color: 'rgba(255,255,255,0.06)' },
                pointLabels: { color: '#94a3b8', font: { size: 9 } }
              }
            }
          }
        });
      } else {
        radarInstance.current.data.datasets[0].data = [
          maintainabilityIndex,
          coveragePct,
          Math.max(40, 100 - cyclomaticComplexity * 8),
          100 - defectProbability,
          95
        ];
        radarInstance.current.update();
      }
    }
  }, [maintainabilityIndex, coveragePct, cyclomaticComplexity, defectProbability]);

  const executePipeline = async (targetPrompt = prompt) => {
    const t0 = performance.now();
    try {
      const res = await fetch('/api/swe/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: targetPrompt })
      });
      const data = await res.json();
      setLatencyMs(Math.round(performance.now() - t0));

      const m = data.code_data.metrics;
      const mi = m.maintainability_index || 65.0;
      setMaintainabilityIndex(mi);
      setCyclomaticComplexity(m.cyclomatic_complexity);
      setLoc(m.loc);
      setAstDepth(m.ast_depth);
      setDefectRisk(data.defect_audit.risk_label);
      setDefectProbability(Number((data.defect_audit.defect_probability * 100).toFixed(1)));
      setTestStatus(data.test_results.test_suite_status);
      setCoveragePct(data.test_results.coverage_pct);

      let out = `======================================================================
1. ARCHITECT AGENT & RAG DESIGN PATTERN:
Module Target   : ${data.specification.module_name}
Category        : ${data.specification.category || "Application Architecture"}
Pattern Match   : ${data.specification.recommended_pattern}
Security Policy : ${data.specification.security_policy}

2. REAL AST STATIC METRICS & MAINTAINABILITY:
LOC: ${m.loc} | Cyclomatic Complexity: ${m.cyclomatic_complexity} | AST Depth: ${m.ast_depth}
Maintainability Index : ${mi} / 100 (${data.defect_audit.maintainability_rating || "ACCEPTABLE"})
ML Defect Probability : ${(data.defect_audit.defect_probability*100).toFixed(2)}% [${data.defect_audit.risk_label}]

3. AUTOMATED SANDBOX TEST SUITE:
Status: ${data.test_results.test_suite_status} (${data.test_results.tests_passed}/${data.test_results.tests_executed} Unit Tests Passed)
Statement Coverage : ${data.test_results.coverage_pct}%

======================================================================
VALIDATED CODE ARTIFACT:
${data.code_data.code}
`;
      setCodeOutput(out);
    } catch (err) {
      setCodeOutput('SWE Swarm API Error: ' + err.message);
    }
  };

  useEffect(() => {
    executePipeline(prompt);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(codeOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div>
      {/* Header */}
      <header>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div className="brand-badge">⚡</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h1 style={{ fontSize: '16px', fontWeight: 800 }}>Autonomous SWE Platform</h1>
              <span className="chip" style={{ color: 'var(--accent-indigo)', borderColor: 'rgba(129,140,248,0.3)' }}>v2.0 React</span>
            </div>
            <p style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Student: Akash Choudhary (12301625 | Roll: 11) | INT422 Capstone</p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div className="chip">PORT: 5002</div>
          <div className="chip">LATENCY: {latencyMs}ms</div>
          <div className="status-chip">
            <span className="pulse-dot"></span>
            <span>MICROSERVICE ONLINE</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main>
        {/* 4-Stage Agent State Pipeline */}
        <div className="pipeline-tracker">
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 1: Architect</div>
            <div className="pipeline-title">Requirement RAG</div>
            <div className="pipeline-desc">Gang of Four & Clean Architecture decomposition</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 2: Developer</div>
            <div className="pipeline-title">Code Synthesizer</div>
            <div className="pipeline-desc">Modular clean architecture class generator</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 3: AST Analyzer</div>
            <div className="pipeline-title">AST Static Parser</div>
            <div className="pipeline-desc">Real Cyclomatic Complexity & Maintainability Index</div>
          </div>
          <div className="pipeline-node active-node">
            <div className="pipeline-step">Stage 4: Sandbox Tester</div>
            <div className="pipeline-title">Unit Test Runner</div>
            <div className="pipeline-desc">Dynamic validation & statement coverage</div>
          </div>
        </div>

        {/* Metric Cards Row */}
        <div className="grid-4">
          <div className="stat-card">
            <div className="stat-label">Maintainability Index</div>
            <div className="stat-val" style={{ color: maintainabilityIndex > 50 ? 'var(--accent-emerald)' : 'var(--accent-amber)' }}>
              {maintainabilityIndex} / 100
            </div>
            <div className="stat-sub">SEI Metric Standard</div>
          </div>

          <div className="stat-card">
            <div className="stat-label">ML Defect Risk</div>
            <div className="stat-val" style={{ color: defectProbability < 5 ? 'var(--accent-emerald)' : 'var(--accent-amber)' }}>
              {defectProbability}% Prob
            </div>
            <div className="stat-sub">Random Forest Assessment</div>
          </div>

          <div className="stat-card">
            <div className="stat-label">Cyclomatic Complexity</div>
            <div className="stat-val" style={{ color: 'var(--accent-cyan)' }}>
              {cyclomaticComplexity} (LOC: {loc})
            </div>
            <div className="stat-sub">AST Tree Decision Branches</div>
          </div>

          <div className="stat-card">
            <div className="stat-label">Sandbox Test Suite</div>
            <div className="stat-val" style={{ color: testStatus === 'PASS' ? 'var(--accent-emerald)' : 'var(--accent-rose)' }}>
              {testStatus} ({coveragePct}%)
            </div>
            <div className="stat-sub">Automated Statement Coverage</div>
          </div>
        </div>

        {/* 2-Column Main Content */}
        <div className="grid-2">
          {/* Prompt Column */}
          <div>
            <div className="card">
              <div className="card-header">
                <span className="card-title">Software Requirement Specification</span>
                <span className="chip" style={{ fontSize: '10px' }}>Natural Language</span>
              </div>

              <textarea
                style={{ width: '100%', height: '110px', background: '#030712', border: '1px solid var(--border)', borderRadius: '8px', padding: '12px', color: '#fff', fontFamily: 'inherit', fontSize: '13px', resize: 'none' }}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />

              <div className="card-header" style={{ marginTop: '14px', marginBottom: '8px' }}>
                <span className="card-title" style={{ fontSize: '13px' }}>Architectural Presets</span>
              </div>
              <div className="btn-group">
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    const p = 'Build a high-performance sliding window API Rate Limiter in Python with auto cleanup';
                    setPrompt(p);
                    executePipeline(p);
                  }}
                >
                  Rate Limiter Middleware
                </button>
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    const p = 'Design and implement a thread-safe O(1) LRU Cache with mutex locking';
                    setPrompt(p);
                    executePipeline(p);
                  }}
                >
                  Thread-Safe LRU Cache
                </button>
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    const p = 'Create a stateless HMAC-SHA256 JWT Auth token validator with expiry checks';
                    setPrompt(p);
                    executePipeline(p);
                  }}
                >
                  JWT Token Validator
                </button>
              </div>

              {/* Radar Chart Canvas */}
              <div className="card-header" style={{ marginTop: '16px', marginBottom: '8px' }}>
                <span className="card-title" style={{ fontSize: '12px' }}>📊 AST Code Quality Radar</span>
              </div>
              <div style={{ position: 'relative', height: '150px', width: '100%' }}>
                <canvas ref={radarRef}></canvas>
              </div>

              <button className="btn" style={{ marginTop: '16px', width: '100%', justifyContent: 'center' }} onClick={() => executePipeline(prompt)}>
                🚀 Trigger Multi-Agent SWE Swarm
              </button>
            </div>
          </div>

          {/* Code Viewer Column */}
          <div>
            <div className="card">
              <div className="card-header">
                <span className="card-title">Validated Code Artifact & Audit Trace</span>
                <button className="btn btn-outline" onClick={handleCopy}>
                  {copied ? '✓ Copied!' : '📋 Copy Code Artifact'}
                </button>
              </div>
              <div className="terminal-box">{codeOutput}</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
